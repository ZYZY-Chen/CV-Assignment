set -euo pipefail
[[ "$(id -un)" == huajie001 && "$HOME" == /home/mcaai/huajie001 ]] || { echo 'Unexpected remote identity or HOME.' >&2; exit 2; }
root=/home/mcaai/huajie001/ca6129_v2_setup
[[ ! -L "$root" && "$(readlink -m -- "$root")" == "$root" ]] || { echo 'Unexpected root or symbolic link.' >&2; exit 2; }
for relative in run run/setup_v2 configs scripts tmp _downloads _package_cache envs; do
    candidate="$root/$relative"
    [[ ! -L "$candidate" && "$(readlink -m -- "$candidate")" == "$candidate" ]] || { echo "Unsafe staging path: $relative" >&2; exit 2; }
done
[[ -d "$root" && -d "$root/run/setup_v2" && ! -L "$root/run/setup_v2" && ! -L "$root/tmp" ]] || exit 2
cd -- "$root"
if [[ -n "$(squeue --noheader --user=huajie001 --format=%i)" ]]; then
    echo 'A personal job is already queued or running. Collect it before submitting another setup job.' >&2
    exit 2
fi
probe_id=$(cat run/setup_v2/last_probe_job.txt)
[[ "$probe_id" =~ ^[0-9]+$ ]] || exit 2
grep -Eq '"ready": true' "run/setup_v2/job_${probe_id}_hardware/hardware.json" || { echo 'Hardware gate not passed.' >&2; exit 2; }
environment_job=$(cat run/setup_v2/last_prepare_environment_job.txt)
[[ "$environment_job" =~ ^[0-9]+$ && -x "$root/envs/ca6129-ad-v2/bin/python" ]] || exit 2
grep -Eq '"ready": true' "run/setup_v2/job_${environment_job}_prepare_environment/preparation_status.json" || { echo 'Dedicated package environment not ready.' >&2; exit 2; }
inputs_job=$(cat run/setup_v2/last_prepare_inputs_job.txt)
environment_check_job=$(cat run/setup_v2/last_check_environment_job.txt)
[[ "$inputs_job" =~ ^[0-9]+$ && "$environment_check_job" =~ ^[0-9]+$ ]] || exit 2
grep -Eq '"ready": true' "run/setup_v2/job_${inputs_job}_prepare_inputs/preparation_status.json" || { echo 'Input restoration not ready.' >&2; exit 2; }
grep -Eq '"environment_ready": true' "run/setup_v2/job_${environment_check_job}_environment/setup_status.json" || { echo 'GPU environment check not ready.' >&2; exit 2; }
job_id=$(sbatch --parsable --partition=MGPU-TC2 --qos=normal --export=ALL,TC2_ANACONDA_MODULE=anaconda/25.5.1 --output="$root/run/setup_v2/slurm-%j.out" --error="$root/run/setup_v2/slurm-%j.err" scripts/slurm/check_setup_v2.sh "$root/envs/ca6129-ad-v2" all)
job_id=${job_id%%;*}
[[ "$job_id" =~ ^[0-9]+$ ]] || exit 2
printf '%s\n' "$job_id" > run/setup_v2/last_check_all_job.txt
echo "TC2_JOB_ID=$job_id"
for attempt in 1 2 3 4; do
    [[ -n "$(squeue --noheader --jobs="$job_id" --format=%i)" ]] || break
    sleep 10
done

echo '[Personal queue]'
squeue --user=huajie001
if [[ -n "${job_id:-}" ]]; then
    echo "TC2_JOB_ID=$job_id"
    sacct --jobs="$job_id" --user=huajie001 --format=JobID,JobName,State,ExitCode,Elapsed,NodeList || true
    for log in "$root/run/setup_v2/slurm-$job_id.out" "$root/run/setup_v2/slurm-$job_id.err"; do
        if [[ -f "$log" && ! -L "$log" ]]; then echo "[Tail: $log]"; tail -n 50 -- "$log"; fi
    done
fi
cd -- "$root"
archive="$root/tmp/collect_20261019_072848_b0788719.tar.gz"
list="$root/tmp/collect_20261019_072848_b0788719.list"
[[ ! -e "$archive" && ! -e "$list" ]] || exit 2
find run/setup_v2 -type f -print0 > "$list"
for extra in configs/tc2_setup.json environment-tc2.yml requirements-tc2-lock.txt; do
    if [[ -f "$extra" && ! -L "$extra" ]]; then printf '%s\0' "$extra" >> "$list"; fi
done
set +e
tar --null --verbatim-files-from --hard-dereference -czf "$archive" -T "$list"
tar_code=$?
set -e
[[ "$tar_code" -le 1 ]] || exit "$tar_code"
[[ "$(stat -c %s -- "$archive")" -le 67108864 ]] || { echo 'Output archive exceeds 64 MiB.' >&2; exit 2; }
echo "TC2_ARTIFACT_SHA256=$(sha256sum "$archive" | cut -d' ' -f1)"
echo __TC2_ARTIFACT_BEGIN__
base64 -w 76 -- "$archive"
echo __TC2_ARTIFACT_END__
