Unknown existing source. Preserve.
