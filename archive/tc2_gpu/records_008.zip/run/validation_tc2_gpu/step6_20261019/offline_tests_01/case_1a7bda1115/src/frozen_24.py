# Frozen fixture 24
