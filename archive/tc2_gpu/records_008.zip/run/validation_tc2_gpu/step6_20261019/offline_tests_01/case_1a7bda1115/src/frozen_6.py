# Frozen fixture 6
