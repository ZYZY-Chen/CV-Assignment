Existing submission copy: preserve.
